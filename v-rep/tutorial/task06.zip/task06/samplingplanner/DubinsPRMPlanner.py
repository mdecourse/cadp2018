#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import math
import numpy as np

import collections
import heapq

import matplotlib.pyplot as plt

import Environment as env

class DubinsPRMPlanner:

    def __init__(self, limits):
        """
        Parameters
        ----------
        limits: list((float, float))
            translation limits in individual axes 
        """
        self.limits = limits

    def plan(self, environment, start, goal):
        """
        Method to plan the path

        Parameters
        ----------
        environment: Environment
            Map of the environment that provides collision checking 
        start: numpy array (6x1)
            start configuration of the robot (x,y,z,phi_x,phi_y,phi_z)
        goal: numpy array (6x1)
            goal configuration of the robot (x,y,z,phi_x,phi_y,phi_z)

        Returns
        -------
        list(numpy array (4x4))
            the path between the start and the goal Pose in SE(3) coordinates
        """
        path = []
        #TODO: task05 - implement the PRM planner

        ###########################
        ## Construct the start pose
        ###########################
        #construct the rotation matrix and the translation vector for the SE(3) representation of the environment
        R = self.rotation_matrix(start[5],start[4],start[3])
        T = start[0:3]

        #construct the SE(3) matrix
        P_start = np.hstack((R,T.reshape((3,1))))
        P_start = np.vstack((P_start,[0,0,0,1]))

        ###########################
        ## Construct the goal pose
        ###########################
        #construct the rotation matrix and the translation vector for the SE(3) representation of the environment
        R = self.rotation_matrix(goal[5],goal[4],goal[3])
        T = goal[0:3]

        #construct the SE(3) matrix
        P_goal = np.hstack((R,T.reshape((3,1))))
        P_goal = np.vstack((P_goal,[0,0,0,1]))

        #add the points to the path
        path.append(P_start)
        path.append(P_goal)
         
        return(path)
    
    def rotation_matrix(self, yaw, pitch, roll):
        """
        Constructs rotation matrix given the euler angles
        yaw = rotation around z axis
        pitch = rotation around y axis
        roll = rotation around x axis

        Parameters
        ----------
        yaw: float
        pitch: float
        roll: float
            respective euler angles
        """
        R_x = np.array([[1, 0, 0],
                        [0, math.cos(roll), math.sin(roll)],
                        [0, -math.sin(roll), math.cos(roll)]])
        R_y = np.array([[math.cos(pitch), 0, -math.sin(pitch)],
                        [0, 1, 0],
                        [math.sin(pitch), 0, math.cos(pitch)]])
        R_z = np.array([[math.cos(yaw), math.sin(yaw), 0],
                        [-math.sin(yaw), math.cos(yaw), 0],
                        [0, 0, 1]])

        R = R_x.dot(R_y).dot(R_z)
        return R

