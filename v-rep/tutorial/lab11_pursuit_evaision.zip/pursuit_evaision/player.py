# -*- coding: utf-8 -*-
"""
@author: P.Cizek
"""
import numpy as np

import grid_map as mp
import planner as pl

import time

import random

PURSUER = 1
EVADER = 2

GREEDY = "GREEDY"
MONTE_CARLO = "MONTE_CARLO"
VALUE_ITERATION = "VALUE_ITERATION"

class player:
	def __init__(self, robots, role, policy=GREEDY, color='r', timeout=0.5):
		#list of the player's robots
		self.robots = robots[:]
		#next position of the player's robots
		self.next_robots = robots[:]
	
		if role == "EVADER":
			self.role = EVADER
		if role == "PURSUER":
			self.role = PURSUER
		
		#selection of the policy
		if policy == GREEDY:
			self.policy = self.greedy_policy
		if policy == MONTE_CARLO:
			self.policy = self.monte_carlo_policy
		if policy == VALUE_ITERATION:
			self.policy = self.value_iteration_policy
		
		self.color = color #color for plotting purposes
		self.timeout = timeout
		self.Planner = pl.Planner()
                self.values = None
	
	def get_role(self):
		return self.role
	
	def set_role(self, role):
		self.role = role
	
	def get_robots(self):
		return self.robots
	
	def add_robot(self, pos):
		self.robots.append(pos)
		self.next_robots.append(pos)
	
	def del_robot(self, pos):
		idx = self.robots.index(pos)
		self.robots.pop(idx)
		self.next_robots.pop(idx)
	
	def get_color(self):
		return self.color
	
	def calculate_step(self, grid_map, evaders, pursuers):
		#calculate a single step using selected policy
		self.policy(grid_map, evaders, pursuers)
	
	def take_step(self):
		self.robots = self.next_robots[:]
	
	#####################################################
	# Individual policies for taking next step
	#####################################################
	def greedy_policy(self, grid_map, evaders, pursuers):
		self.next_robots = self.robots[:]
		
		#for each robot plan actions
		for idx in range(0, len(self.robots)):
			robot = self.robots[idx]
			
			options = grid_map.neighbors4(robot)
			
			######################################################
			#TODO implementation of greedy policy
			######################################################
			
			if self.role == PURSUER:
				pos_selected = random.choice(options)
		
			if self.role == EVADER:
				pos_selected = random.choice(options)
			
			self.next_robots[idx] = pos_selected
	
	def monte_carlo_policy(self, grid_map, evaders, pursuers):
		self.next_robots = self.robots[:]
		
		######################################################
		#TODO implementation of monte carlo tree search policy
		######################################################
		pass
	
	def value_iteration_policy(self, grid_map, evaders, pursuers):
		self.next_robots = self.robots[:]
			
		######################################################
		#TODO implementation of value iteration policy
		######################################################
		pass
		
	
	#####################################################
	# Helper functions
	#####################################################
	def dist(self, grid_map, id1, id2):
		#using A* to get shortest path
		dst = len(self.Planner.plan(grid_map, id1, id2))
		return dst

