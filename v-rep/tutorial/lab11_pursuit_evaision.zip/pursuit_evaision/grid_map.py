# -*- coding: utf-8 -*-
"""
@author: P.Cizek
"""
import sys
import numpy as np
import math
from PIL import Image
import matplotlib.pyplot as plt

##################################################
# Class for map handling
##################################################
class Grid_map:
	def __init__(self):
		# map
		self.grid = None
		self.width = None
		self.height = None
		# v-rep helper variables
		self.filename = None
		self.sizeX = None
		self.sizeY = None
		self.offsetX = None
		self.offsetY = None
		self.voxelSize = None
	
	def from_file(self, filename, size, offset, voxelSize):
		#map initialization from image file
		self.filename = filename
		(self.sizeX, self.sizeY) = size
		(self.offsetX, self.offsetY) = offset
		self.voxelSize = voxelSize
		
		assert self.sizeX > 0, "Wrong width of the map"
		assert self.sizeY > 0, "Wrong height of the map"
		assert (self.voxelSize > 0 and self.voxelSize < self.sizeX and self.voxelSize < self.sizeY), "Wrong voxel size"
		
		#read map from file
		img = self.read_map(self.filename)
		
		#voxelize the map
		self.width = int(round(self.sizeX/self.voxelSize))
		self.height = int(round(self.sizeY/self.voxelSize))
		img = img.resize((self.width, self.height), Image.ANTIALIAS)
		
		#binarize img
		self.grid = np.empty([self.width, self.height], dtype=np.uint8)
		for r in range(0, self.height):
			for c in range(0, self.width):
				pix = img.getpixel((c, r))
				if isinstance(pix, list):
					self.grid[c, r] = 1 if pix[0] < 50 else 0
				else:
					self.grid[c, r] = 1 if pix < 50 else 0
				
	def read_map(self, filename):
		#read map from the image file
		im = None
		try:
			im = Image.open(filename)
		except:
			print("Failed to load the map")
			sys.exit(1)
		return im
	
	##################################################
	# Getters and Setters
	##################################################
	def get_width(self):
		return self.width
	
	def get_height(self):
		return self.height
	
	def get_cell(self, id):
		#get content of the grid cell
		(x, y) = id
		ret = None
		if self.in_bounds(id):
			ret = self.grid[x, y]
		return ret
	
	def set_cell(self, id, value):
		#set content of the grid cell
		(x, y) = id
		ret = self.in_bounds(id)
		if ret:
			self.grid[x, y] = value
		return ret
	
	def get_grid(self):
		#get the whole map
		return self.grid
	
	def set_grid(self, grid):
		#set the whole map
		(w, h) = np.shape(grid)
		
		if self.filename == None:
			#if there is no binding to file just set up the map
			self.width = w
			self.height = h
			self.grid = np.copy(grid)
		else:
			#...else there is a binding to file and thus to vrep. Modifications to grid size would corrupt coordinates
			assert self.width == w and self.height == h, "wrong size of grid for assignment"
			self.grid = grid
	
	##################################################
	# Helper functions for planning
	##################################################
	
	def in_bounds(self, id):
		#check the boundaries of the map
		(x,y) = id
		return 0 <= x < self.width and 0 <= y < self.height
	
	def passable(self, id):
		#check the passability of the given cell
		(x,y) = id
		return self.grid[x,y] == 1
	
	def neighbors4(self, id):
		#returns coordinates of passable neighbors of the given cell in 4-neighborhood
		(x,y) = id
		results = [(x+1, y), (x, y-1), (x-1, y), (x, y+1)]
		results = filter(self.in_bounds, results)
		results = filter(self.passable, results)
		return results
	
	def neighbors8(self, id):
		#returns coordinates of passable neighbors of the given cell in 8-neighborhood
		(x,y) = id
		results = [(x+1, y+1), (x+1, y), (x+1, y-1),
				   (x,   y+1),           (x,   y-1),
				   (x-1, y+1), (x-1, y), (x-1, y-1)]
		results = filter(self.in_bounds, results)
		results = filter(self.passable, results)
		return results
	
	def cost_euclidean_squared(self, id1, id2):
		#squared the euclidean distance between two points
		(x1, y1) = id1
		(x2, y2) = id2
		return (x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2)
	
	def cost_euclidean(self, id1, id2):
		#the euclidean distance between two points
		return math.sqrt(self.cost_euclidean_squared(id1, id2))

	def cost_euclidean_path(self, path):
		#the euclidean distance of the path
		dst = 0
		last = path[0]
		for act in path:
			dst = dst + self.cost_euclidean(last, act)
			last = act
		return dst
		#return math.sqrt(self.cost_euclidean_squared(id1, id2))
	
	def cost_manhattan(self, id1, id2):
		#the manhattan distance between two points
		(x1, y1) = id1
		(x2, y2) = id2
		return abs(x1 - x2) + abs(y1 - y2)
	
	def all_nodes(self):
		nodes = []
		for x in range(self.get_width()):
			for y in range(self.get_height()):
				if self.in_bounds((x,y)) and self.passable((x,y)):
					nodes = nodes + [(x,y)]
		return nodes

	##################################################
	# Helper functions for creating neighborhoods
	##################################################

	def target_neighbors(self, id, radius):
		#returns neighborhood around the specific target
		(x,y) = id
		results = []
		rd = (int)(radius) + 1
		for dx in range(-rd, rd + 1):
			for dy in range(-rd, rd + 1):
				act = (x+dx,y+dy)
				if self.cost_euclidean(id, act) < radius :
					results = results + [act]
		results = filter(self.in_bounds, results)
		results = filter(self.passable, results)
		return results
	
	##################################################
	# Helper functions for V-REP interfacing
	##################################################
	def point_to_vrep(self, id):
		#function to return real-world coordinates
		(x, y) = id
		if self.filename == None:
			return None
		else:
			return (x*self.voxelSize - self.offsetX, -y*self.voxelSize + self.offsetY)
	
	def vrep_to_point(self, id):
		(x, y) = id
		if self.filename == None:
			return None
		else:
			return (round((x + self.offsetX)/self.voxelSize), round(-(y - self.offsetY)/self.voxelSize))


