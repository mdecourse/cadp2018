#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
@author: P.Cizek
"""

import sys
import re
import numpy as np
import random

import grid_map as mp
import game as game

import player as pl

import matplotlib.pyplot as plt

################################################
# Testing scenarios
################################################
#maze name, (size_x, size_y) in vrep, (offset_x, offset_y) for coordinates transformation, voxel_size, configuration file
test = ("./mazes/pacman.png", (19,21), (0,0), 1, "./mazes/pacman.game")
#test = ("./mazes/pacman_small.png", (11,13), (0,0), 1, "./mazes/pacman_small.game")
#test = ("./mazes/grid4x4.png", (9,9), (0,0), 1, "./mazes/grid4x4.game")

#instantiation of the map
grid_map = mp.Grid_map()
grid_map.from_file(test[0], test[1], test[2], test[3])

#load the game configuration
players = []
with open(test[4]) as fp:
	for line in fp:
		if line[0] == "#": # skip comments
			continue
		q = line.split()
		
		role = q[0]
		policy = q[1]
		color = q[2]
		robots = []
		for x in range(3,len(q),2):
			robots.append((int(q[x]),int(q[x+1])))
		
		players.append(pl.player(robots, role, policy, color))

pe_game = game.Game(grid_map, players)
pe_game.plot_game()
pe_game.plot_pause()

######################################
# Simulate the game
######################################
# simulate game of n_steps
n_steps = 100

for i in range(0, n_steps):
	if not pe_game.is_end():
		pe_game.step()
		pe_game.plot_game()
		pe_game.plot_pause(0.01)
		
		#if i == 50:
		#	pe_game.change_status()

# active waiting for end
if not pe_game.is_end():
	print("Evader escaped")
else:
	print("GAME OVER")

while (1):
	pe_game.plot_pause(1)

