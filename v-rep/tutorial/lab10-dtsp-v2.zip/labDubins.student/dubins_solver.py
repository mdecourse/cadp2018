# -*- coding: utf-8 -*-
"""
@author: P.Vana & P.Cizek
"""
import sys
import os
import numpy as np

import math

import matplotlib.pyplot as plt

from invoke_LKH import *

# dubins library, see: https://github.com/AndrewWalker/pydubins
# install by: "sudo pip install dubins"
import dubins

class Dubins_solver:
	def __init__(self):
		pass
	
	# Solve the given ATSP problem by LKH Solver
	# returns the sequence representing the solutions
	# runs approximately in O(n^{2.2})
	# the found solution is not guaranteed to be optimal (heuristic alg.)
	def solve_ATSP(self, atsp_matrix):
		fname_tsp = "problem"
		user_comment = "a comment by the user"
		writeTSPLIBfile_FE(fname_tsp, atsp_matrix, user_comment)
		run_LKHsolver_cmd(fname_tsp)
		return read_LKHresult_cmd(fname_tsp)
	
	# Find the tour and retun reconstructed tour
	def select_tour(self):
		n = len(self.distances)
		
		sequence = self.solve_ATSP(self.distances)
		
		path = []
		for a in range(0,n):
			b = (a+1) % n
			a_idx = sequence[a]
			b_idx = sequence[b]
			actual_path = self.paths[(a_idx,b_idx)];
			path = path + actual_path
		
		return path
	
	# Solve Dubins TSP
	def plan_tour_dtsp(self, goals, turning_radius, visualizate):
		n = len(goals)
		self.distances = np.zeros((n,n))	
		self.paths = {}
		
		# find path between each pair of goals (a,b)
		for a in range(0,n): 
			for b in range(0,n):
				g1 = goals[a]
				g2 = goals[b]
				if a != b:
					# find the shortest path
					sh_path = [g1[:2]] + [g2[:2]]
					# store distance
					q0 = ((g1[0], g1[1], 0))
					q1 = ((g2[0], g2[1], 0))
					self.distances[a][b] = dubins.path_length(q0, q1, turning_radius)
					# store path
					samples,_ = dubins.path_sample(q0, q1, turning_radius, turning_radius * 0.1)
					self.paths[(a,b)] = samples

		return self.select_tour()
	
