#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
@author: P.Vana & P.Cizek
"""

import sys
import re
import numpy as np

import helper as hlp
import dubins_solver as ds

import matplotlib.pyplot as plt

# dubins library, see: https://github.com/AndrewWalker/pydubins
# install by: "sudo pip install dubins"
import dubins

################################################
# Testing
################################################
# 1) file with cities containing coordinates (idx, x, y) separated by new-line symbol
# 2) radius of the neighborhoods
# 3) radius of the Dubins vehicle
#test = ("./problems/burma14.txt", 0, 0.3)
#test = ("./problems/att48.txt", 0, 200)
test = ("./problems/mbzirc22.txt", 0, 3.0)

visualize = True
#visualize = False

# read config with goal positions
goals = []
with open(test[0]) as fp:
	for line in fp:
		label, x, y = line.split()
		goals.append((float(x), float(y)))

radius = test[1]
turning_radius = test[2]

# plot the target locations
hlp.plot_points(goals, 'og')

######################################
# Tour planning
######################################
solver = ds.Dubins_solver()
path = solver.plan_tour_dtsp(goals, turning_radius, visualize)
hlp.plot_points(path, 'r')
hlp.pause(1)

# active waiting for end
while (visualize):
	hlp.pause(1)

