# -*- coding: utf-8 -*-
"""
@author: P.Vana & P.Cizek
"""
import sys
import os
import numpy as np

import math

import map as mp
import planner as pl

import matplotlib.pyplot as plt

from invoke_LKH import *

class MGMP_solver:
	
	# Initialization
	# Arguments:
	#   euclidean_distance - force to use Euclidean distance
	def __init__(self, neigh, euclidean_distance = False):
		self.euclidean_distance = euclidean_distance
		self.neigh = neigh
		self.planner = pl.Planner();
		pass
	
	# Solve the given ATSP problem by LKH Solver
	# returns the sequence representing the solutions
	# runs approximately in O(n^{2.2})
	# the found solution is not guaranteed to be optimal (heuristic alg.)
	def solve_ATSP(self, atsp_matrix):
		fname_tsp = "problem"
		user_comment = "a comment by the user"
		writeTSPLIBfile_FE(fname_tsp, atsp_matrix, user_comment)
		run_LKHsolver_cmd(fname_tsp)
		return read_LKHresult_cmd(fname_tsp)
	
	# Find the tour and retun reconstructed tour
	def select_tour(self):
		n = len(self.distances)
		
		sequence = self.solve_ATSP(self.distances)
		
		path = []
		for a in range(0,n):
			b = (a+1) % n
			a_idx = sequence[a]
			b_idx = sequence[b]
			actual_path = self.paths[(a_idx,b_idx)];
			path = path + actual_path
		
		return path
	
	# Find the shortest path between two goals
	def find_path_p2p(self, map, g1, g2, euclidean_distance = False):
		# Euclidean distance is forced
		if self.euclidean_distance or euclidean_distance:
			path = [g1[:2]] + [g2[:2]]
		else:
			path = self.planner.plan(map, g1[:2], g2[:2], self.neigh)
		return path

	# Find a shortest tour utilizing Euclidean distances which does not consider obstacles in the maze.
	# goals - list of target centroids
	def plan_etsp(self, map, goals):
		n = len(goals)
		# distance matrix
		self.distances = np.zeros((n,n))	
		# dictionary of all sub-paths
		self.paths = {}

		# find path between each pair of goals (a,b)
		for a in range(0,n): 
			for b in range(0,n):
				g1 = goals[a]
				g2 = goals[b]
				if a != b:
					# find the shortest path
					sh_path = self.find_path_p2p(map, g1, g2, True)
					# store distance
					self.distances[a][b] = map.cost_euclidean_path(sh_path) 
					# store path
					self.paths[(a,b)] = sh_path
					
		return self.select_tour()

	# Find a shortest tour utilizing distances computed by A* algorithm
	# goals - list of target centroids
	def plan_tsp(self, map, goals):	
		n = len(goals)
		# distance matrix
		self.distances = np.zeros((n,n))	
		# dictionary of all sub-paths
		self.paths = {}

		# find path between each pair of goals (a,b)
		for a in range(0,n): 
			print('Shortest paths from city {0}'.format(a))
			for b in range(0,n):
				if a != b:
					g1 = goals[a]
					g2 = goals[b]
				
					# find the shortest path
					sh_path = self.find_path_p2p(map, g1, g2)
					# store distance
					self.distances[a][b] = map.cost_euclidean_path(sh_path)  
					# store path
					self.paths[(a,b)] = sh_path

		return self.select_tour()
	
	# First part of HW03
	# 1) Find the target sequence by considering distances between target centroids
	# 2) Compute all distances between all the samples, but only in the determined target sequence
	# 3) Find a shortest tour.
	# Part 1) is already prepared nad parts 2), 3) need to be implemented
	def plan_tspn_decoupled(self, map, goals, samples):	
		n = len(goals)
		# distance matrix
		self.distances = np.zeros((n,n))	
		# dictionary of all sub-paths
		self.paths = {}
		
		# find path between each pair of goals (a,b)
		for a in range(0,n): 
			print('Shortest paths from city {0}'.format(a))
			for b in range(0,n):
				if a != b:
					g1 = goals[a]
					g2 = goals[b]
				
					# find the shortest path
					sh_path = self.find_path_p2p(map, g1, g2)
					# store distance
					self.distances[a][b] = map.cost_euclidean_path(sh_path)  
					# store path
					self.paths[(a,b)] = sh_path
					
		#TODO - use selected target sequence and find the shortest loop

		return self.select_tour()
	
	# Second part of HW03
	# 1) Compute all distances between all the samples, but only in the determined target sequence
	# 2) Transform the problem into the ATSP by the Noon-Bean transformation
	# 3) Solve the ATSP by LKH MGMP_solver
	# 4) Reconstruct the final trajectory back
	def plan_tspn_noon_bean(self, map, samples):	
		# number of goal regions
		N = len(samples)
		# total number of samples
		K = 0
		
		# dictionary - samples to index
		# sample2idx[(x, y)] = z
		# x - number of goal region in range(N)
		# y - number of samle in the region in range(len(samples[x]))
		# z - global index of the sample (used in the distance matrix)
		sample2idx = {}
		# dictionary - index to samples
		idx2sample = {}
		
		# pripare dictionaries
		for a in range(N):
			a_samples = samples[a]
			a_len = len(a_samples)
			for idx_a in range(a_len):
				sample2idx[(a, idx_a)] = K + idx_a
				idx2sample[K + idx_a] = (a, idx_a) 
			K += a_len
		
		# distance matrix between all samples
		self.distances = np.zeros((K,K))	
		# dictionary of the found path between samples
		# key is (x,y) wher x,y are indexes of samples
		self.paths = {}
		for x in range(K):
			for y in range(K):
				self.paths[(x,y)] = []

		# find path between each pair of goals (a,b)
		for a in range(N): 
			for b in filter(lambda x : x!=a, range(N)):
				a_samples = samples[a]
				b_samples = samples[b]
				print('Paths between sets {} and {}'.format(a, b))
				for a_idx in range(len(a_samples)): 
					for b_idx in range(len(b_samples)):
						g1 = samples[a][a_idx]
						g2 = samples[b][b_idx]
						
						# find the shortest path
						sh_path = self.find_path_p2p(map, g1, g2)
						# store distance
						global_idx_a = sample2idx[(a, a_idx)]
						global_idx_b = sample2idx[(b, b_idx)]
						# store distance
						self.distances[global_idx_a][global_idx_b] = map.cost_euclidean_path(sh_path)
						# store path
						self.paths[(global_idx_a, global_idx_b)] = sh_path
						
		self.distances = self.distances * 1000
		atsp = self.distances.copy()
		# create zero length cycles
		
		# set big M constant
		M = np.max(np.max(atsp)) * N / 2
		
		# nubmer of samples in each group
		# TODO - Noon-Bean transformation
		
		sequence = self.solve_ATSP(atsp)
		print(sequence)
		
		path = []
		# TODO - reconstruct the final tour

		return path
	 
	 
	
