#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@author: P.Cizek
"""
import sys
import numpy as np

import math

import collections
import heapq

import map as mp
import time

class Planner:
	def __init__(self):
		# set function for the shortest path planning
		self.used_planner = self.a_star_search
		# set function for neighborhood selection ("E4", "E8")
		self.neigh_structure = None
	
	#########################################
	# A_STAR
	#########################################
	
	class PriorityQueue:
		def __init__(self):
			self.elements = []
	
		def empty(self):
			return len(self.elements) == 0
	
		def put(self, item, priority):
			heapq.heappush(self.elements, (priority, item))
	
		def get(self):
			return heapq.heappop(self.elements)[1]
	
	def heuristic(self, a, b):
			(x1, y1) = a
			(x2, y2) = b
			return math.sqrt((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2))
	
	def a_star_search(self, graph, start, goal):
		open_set = self.PriorityQueue()
		open_set.put(start, 0)
		came_from = {}
		cost_so_far = {}
		came_from[start] = None
		cost_so_far[start] = 0
		
		while not open_set.empty():
			current = open_set.get()
			if current == goal:
				break

			if self.neigh_structure == "E4":
				next_set = graph.neighbors4(current)
			elif self.neigh_structure == "E8":
				next_set = graph.neighbors8(current)
			else:
				raise Exception("Unknown neighborhood! (E4/E8)")
		
			for next in next_set:
				new_cost = cost_so_far[current] + graph.cost_euclidean_squared(current, next)
				if next not in cost_so_far or new_cost < cost_so_far[next]:
					cost_so_far[next] = new_cost
					priority = new_cost + self.heuristic(goal, next)
					open_set.put(next, priority)
					came_from[next] = current
	
		return came_from, cost_so_far
	
	#########################################
	# backtracking function
	#########################################
	
	def reconstruct_path(self, came_from, start, goal):
		current = goal
		path = [current]
		while current != start:
			current = came_from[current]
			path.append(current)
		path.append(start) # optional
		path.reverse() # optional
		return path
	
	#########################################
	# Planning function
	#########################################
	
	def plan(self, map, start, goal, neigh):
		self.neigh_structure = neigh
		came_from, cost_so_far = self.used_planner(map, start, goal)
		path = self.reconstruct_path(came_from, start, goal)
		return path
	
	#########################################
	# Execution function
	# -drive the robot through the maze
	#########################################
	
	def execute(self, map, start, goal):
		path = self.plan(map, start, goal)
		"""
		here add your code for robot control
		"""
		return True
		
