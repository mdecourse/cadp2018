#!/usr/bin/env python2

import sys
import re
import numpy as np
import random

import map as mp
import helper as hlp
import mgmp_solver as mgmp

import matplotlib.pyplot as plt

# enable to use Euclidean distances (without obstacles) for testing
use_euclidean = False
#use_euclidean = True

#instantiation of map and planner
map = mp.Map()

# planner settings
# 1) Type of neighborhoods structure for grid-base planning ("E4"/"E8")
# 2) Force to use Euclidean distances (planning without obstacles)
solver = mgmp.MGMP_solver("E8", use_euclidean)

################################################
# Testing
################################################
test = ("./mazes/maze1.png",(10,8.6),(5,4.3),0.1,"./mazes/maze1.config")

#read map
map.from_file(test[0],test[1],test[2],test[3])

#read config with goal positions
goals = []
with open(test[4]) as fp:
	for line in fp:
		x, y, radius = line.split()
		goals.append((int(x), int(y), float(radius)))

# maximum number of samples
SAMPLES_MAX = 6

# set random seed
random.seed(42)
# create neighborhoods (only for TSPN -- with neighborhoods)
samples={}
for i in range(0, len(goals)):
	g = goals[i]
	ne = map.target_neighbors((g[0], g[1]), g[2])
	# random orders
	random.shuffle(ne)
	if len(ne) > SAMPLES_MAX:
		ne = ne[0:SAMPLES_MAX]
	print('Goal {} - {} samples:'.format(g, len(ne)))
	print(ne)
	samples[i] = ne

######################################
# plot arena and goals (and their neighborhoods)
######################################
#plot map
hlp.plot_map(map.get_grid())
#plot neighborhoods
for i in range(0, len(goals)):
	ne = samples[i]
	#print(ne)
	hlp.plot_points(ne, 'go')
#plot goals
hlp.plot_points(goals, 'ro')

######################################
#tour planning
######################################
tour = solver.plan_etsp(map, goals)
#tour = solver.plan_tsp(map, goals)
#tour = solver.plan_tspn_decoupled(map, goals, samples)
#tour = solver.plan_tspn_noon_bean(map, samples)

# plot final tour
hlp.plot_points(tour, 'r')

# print results with active waiting
while (1):
	hlp.pause(1)

