import sys
import numpy as np
import math
import matplotlib.pyplot as plt

##################################################
# Helper functions for map plotting
##################################################
def clear():
	plt.clf()
	plt.axis('equal')

def pause(time = 1):
	plt.pause(time)
	
def plot_map(grid_map):
	#method to plot the grid map given as 2D numpy array
	plt.clf()
	plt.imshow(np.transpose(grid_map), cmap="hot", interpolation='nearest')
	#plt.draw()

def plot_path(grid_map, path):
	#method to plot the path given as sequence of points connected by straight line
	plt.imshow(np.transpose(grid_map), cmap="hot")
	x_val = [x[0] for x in path]
	y_val = [x[1] for x in path]
	plt.plot(x_val,y_val)
	plt.plot(x_val,y_val,'or')
	plt.draw()

def plot_points(points, specs = 'r'):
	x_val = [x[0] for x in points]
	y_val = [x[1] for x in points]
	plt.plot(x_val, y_val, specs)
	#plt.draw()

def plot_edges(edges, specs = 'g'):
	for tup in edges:
		x_val = [x[0] for x in tup]
		y_val = [x[1] for x in tup] 
		plt.plot(x_val, y_val, specs)
	plt.draw()

def save_figure(filename):
	plt.gcf().savefig(filename)

