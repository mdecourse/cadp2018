#ifndef RAPID_VERSION_H
#define RAPID_VERSION_H

static char rapid_version[] = "RAPIDTAG:  RAPID v. 2.01 -- Thu Jul  3 12:54:37 EDT 1997";

#endif
